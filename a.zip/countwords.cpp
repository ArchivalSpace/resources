// Description:
//  Countwords thread for reading words from a test file, and for
//  every word read in from the test file. search and count the
//  number of words in the dictionary tree that start with this
//  word, if the count is equal to or greater than the number
//  specified by an optional command line argument (default
//  is 1 if not specified), print this word and the count
//  (separated by a space) to a file named countwords_output.txt,
//  ONE line per word.
//
// REDID:
//  823984402
//
// Parameters:
//  argc - number of command line arguments
//  argv - array of command line arguments: String; String; Bool
//  optional: -p Flags; -h Flags: hash mark for integral; -n Flags;
//
// Returns:
//  0
#define NUMOFCHARS 27 /* a-z plus ' */
#define APOSTROPHE 26
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <stdio.h>
#include <string.h>
#include <cstring>

#include "btrie.h"

using namespace std;

int depthSearch(struct dictNode *currentnode, int &count)
{
    if (currentnode == NULL)
        return 0;

    if (currentnode->isWord)
        count++;
    for (int i = 0; i < NUMOFCHARS; i++)
    {
        if (currentnode->next[i])
        {
            depthSearch(currentnode->next[i], count);
        }
    }
    return count;
}

int search(struct dictNode *root, string prefix)
{
    struct dictNode *node = root;
    for (int i = 0; i < prefix.length(); i++)
    {
        if (node == NULL)
        {
            return 0;
        }
        int index = prefix[i] - 'a';
        if (prefix[i] == '\'')
        {
            index = APOSTROPHE;
        }
        if (!node->next[index])
        {
            return 0;
        }
        node = node->next[index];
    }
    int count = 0;
    depthSearch(node, count);
    return count;
}
