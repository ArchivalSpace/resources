#ifndef DICTTEST_H
#define DICTTEST_H

#define NUMOFFILES 2

#include <stdio.h>
#include <string>

#include "btrie.h"

struct EXEC_STATUS
{
    dictNode *root;
    int numOfProgressMarks;
    int hashmarkInterval;
    int minNumOfWordsWithAPrefixForPrinting;

    long totalNumOfCharsInDictionary;
    long totalNumOfCharsInTestFile;
    long numOfCharsProcessedFromDictionary;
    long numOfCharsProcessedFromTestFile;
    long wordCountInDictionary;
    long wordCountInTestFile;
    bool taskCompletedForDictionary;
    bool taskCompletedForTestFile;

    std::string dictionary_path;
    std::string testfile_path;
    std::string output_file_name;
};

void *populatetree(void *arg);
void *countwords(void *arg);

#endif