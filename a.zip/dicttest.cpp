// Description:
//  The main function for the countwords program. Uses multi-threading to
//  build the dictionary tree and then searches the dictionary tree while
//  displaying the progress with a progress bar.
//
// REDID:
//  823984402
//
// Parameters:
//  argc - number of command line arguments
//  argv - array of command line arguments: String; String; Bool
//  optional: -p Flags; -h Flags: hash mark for integral; -n Flags;
//
// -p N N progress marks (either hyphen or #) for displaying 100% progress of a
//      thread execution, default is 50 if not specified.
//      Minimal number is 10. If a number less than 10 is specified, program
//      should print to the standard output:
//      Number of progress marks must be a number and at least 10
//      then exit.
// -h N place a hash mark “#” in the progress bar every N characters, default is 10
//      if not specified. If an out-of-range number (<=0 or > 10) is specified,
//      program should print to the standard output:
//      Hash mark interval for progress must be a number, greater than 0, and
//      less than or equal to 10 then exit.
// -n N print word and its count (refer to 2. b in Functionality) to an output file
//      (countwords_output.txt) only if the number of dictionary words starting
//      with the word is equal to or greater than N, default is 1 if not specified.
// Returns:
//  0

#define NUMOFCHARS 27 /* a-z plus ' */
#define NUMOFFILES 2
long *numOfCharsProcessedFromFile[NUMOFFILES];
#define DEFAULT_NUMOF_MARKS 50
#define MIN_NUMOF_MARKS 10
#define DEFAULT_HASHMARKINTERVAL 10
#define DEFAULT_MINNUM_OFWORDS_WITHAPREFIX 1

#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <cstring>

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

#include "btrie.h"
#include "countwords.h"
#include "dicttest.h"

const char *DELIMITERS = "\n\r !\"#$%&()*+,-./0123456789:;<=>?@[\\]^_`{|}~";

using namespace std;

void *populatetree(void *arg);
void *searchtree(void *arg);

// Casts string to Char*
char *stringToChar(string str)
{
    char *cstr = new char[str.length() + 1];
    strcpy(cstr, str.c_str());
    return cstr;
}

// Checks File size
unsigned long fileSize(char *file)
{
    FILE *f = fopen(file, "r");
    fseek(f, 0, SEEK_END);
    unsigned long len = (unsigned long)ftell(f);
    fclose(f);
    return len;
}

// Display the progress bar for the dictionary tree
void createProgressBarsForDictionary(EXEC_STATUS *exe)
{
    float progress = 0.0;
    while (!exe->taskCompletedForDictionary)
    {
        progress = (float)exe->numOfCharsProcessedFromDictionary / (float)exe->totalNumOfCharsInDictionary;
        int progressMarks = (int)(progress * (float)exe->numOfProgressMarks);
        cout << "\r";

        int hashindex = 0;
        // Print the progress bar with dashes and hashmark every hashmarkInterval

        for (int i = 0; i < exe->numOfProgressMarks; i++)
        {
            if (i < progressMarks)
            {
                if (hashindex % exe->hashmarkInterval == exe->hashmarkInterval - 1)
                {
                    cout << "#";
                }
                else
                {
                    cout << "-";
                }
            }
            hashindex++;
        }

        cout.flush();
        // usleep(1000);
    }
    progress = (float)exe->numOfCharsProcessedFromDictionary / (float)exe->totalNumOfCharsInDictionary;
    int progressMarks = (int)(progress * (float)exe->numOfProgressMarks);
    cout << "\r";

    int hashindex = 0;
    // Print the progress bar with dashes and hashmark every hashmarkInterval

    for (int i = 0; i < exe->numOfProgressMarks; i++)
    {
        if (i < progressMarks)
        {
            if (hashindex % exe->hashmarkInterval == exe->hashmarkInterval - 1)
            {
                cout << "#";
            }
            else
            {
                cout << "-";
            }
        }
        hashindex++;
    }

    cout.flush();

    cout << endl;
    cout << "There are " << exe->wordCountInDictionary << " words in " << exe->dictionary_path << "." << endl;
}

// Display the progress bar for test file
void createProgressBarsForSearch(EXEC_STATUS *exe)
{
    double progress = 0.0;
    while (!exe->taskCompletedForTestFile)
    {
        progress = (float)exe->numOfCharsProcessedFromTestFile / (float)exe->totalNumOfCharsInTestFile;
        int progressMarks = (int)(progress * (float)exe->numOfProgressMarks);
        cout << "\r";

        int hashindex = 0;
        // Print the progress bar with dashes and hashmark every hashmarkInterval
        for (int i = 0; i < exe->numOfProgressMarks; i++)
        {
            if (i < progressMarks)
            {
                if (hashindex % exe->hashmarkInterval == exe->hashmarkInterval - 1)
                {
                    cout << "#";
                }
                else
                {
                    cout << "-";
                }
            }
            hashindex++;
        }

        cout.flush();
        // usleep(1000);
    }
    progress = (float)exe->numOfCharsProcessedFromTestFile / (float)exe->totalNumOfCharsInTestFile;
    int progressMarks = (int)(progress * (float)exe->numOfProgressMarks);
    cout << "\r";

    int hashindex = 0;
    // Print the progress bar with dashes and hashmark every hashmarkInterval
    for (int i = 0; i < exe->numOfProgressMarks; i++)
    {
        if (i < progressMarks)
        {
            if (hashindex % exe->hashmarkInterval == exe->hashmarkInterval - 1)
            {
                cout << "#";
            }
            else
            {
                cout << "-";
            }
        }
        hashindex++;
    }

    cout.flush();

    cout << endl;
    cout << "There are " << exe->wordCountInTestFile << " words in " << exe->testfile_path << "." << endl;
}

int main(int argc, char *argv[])
{
    struct EXEC_STATUS *exe;
    exe = (struct EXEC_STATUS *)malloc(sizeof(struct EXEC_STATUS));
    string dictionary_path, testfile_path, output_file_name;
    struct dictNode *root = getNode();

    int numOfProgressMarks = 50, hashmarkInterval = 10, minNumOfWordsWithAPrefixForPrinting = 1;
    if (argc < 3)
    {
        cout << "Usage: ./countwords <dictionary_path> <testfile_path> [optional: -p N N] [optional: -h N] [optional: -n N]" << endl;
        return 0;
    }
    else
    {
        dictionary_path = argv[1];
        testfile_path = argv[2];
    }
    output_file_name = "countwords_output.txt";
    int flag;
    while ((flag = getopt(argc, argv, "p:h:n:")) != -1)
    {
        switch (flag)
        {
        case 'p':
            if (optarg != NULL)
                break;
            numOfProgressMarks = atoi(optarg);
            break;
        case 'h':
            if (optarg != NULL)
                break;
            hashmarkInterval = atoi(optarg);
            break;
        case 'n':
            if (optarg != NULL)
                break;
            minNumOfWordsWithAPrefixForPrinting = atoi(optarg);
            break;
        default:
            break;
        }
    }

    // Initialize the exe struct
    exe->numOfProgressMarks = numOfProgressMarks;
    exe->hashmarkInterval = hashmarkInterval;
    exe->minNumOfWordsWithAPrefixForPrinting = minNumOfWordsWithAPrefixForPrinting;
    exe->dictionary_path = dictionary_path;
    exe->testfile_path = testfile_path;
    exe->output_file_name = output_file_name;
    exe->root = root;

    exe->totalNumOfCharsInDictionary = fileSize(stringToChar(dictionary_path));
    exe->totalNumOfCharsInTestFile = fileSize(stringToChar(testfile_path));

    // Initialize pthreads
    pthread_t dictThread, countThread;
    pthread_create(&dictThread, NULL, &populatetree, (void *)exe);
    pthread_create(&dictThread, NULL, &countwords, (void *)exe);

    createProgressBarsForDictionary(exe);
    createProgressBarsForSearch(exe);

    return 0;
}

void *populatetree(void *args)
{
    // Populates exe->root with the dictionary

    // Parse args into struct EXEC_STATUS
    struct EXEC_STATUS *exe = (struct EXEC_STATUS *)args;

    // Build Trie by populating with dictionary source file
    ifstream dictstream(exe->dictionary_path);
    string line;
    while (getline(dictstream, line))
    {
        // Parse variable line from strings to char*
        char *word = strtok((char *)line.c_str(), DELIMITERS);
        while (word != nullptr)
        {
            // call add method to insert word to build the dictionary tree
            addToDictionary(exe->root, word);

            // Add char count to exe->numOfCharsProcessedFromDictionary
            exe->numOfCharsProcessedFromDictionary += strlen(word) + 1; // Delimiter is included
            // And declaring an variable or macro for this is unreasonable.

            exe->wordCountInDictionary++;

            // read next word
            word = strtok(NULL, DELIMITERS);
        }
    }
    dictstream.close();
    exe->taskCompletedForDictionary = true;
    return NULL;
}

void *countwords(void *args)
{
    // Counts the number of words in the test file

    // Parse args into struct EXEC_STATUS
    struct EXEC_STATUS *exe = (struct EXEC_STATUS *)args;
    // Actively wait for the dictionary to be populated
    while (!exe->taskCompletedForDictionary)
    {
        if (true)
        {
        }
    }
    // Load test file
    ifstream teststream(exe->testfile_path);
    ofstream output;
    string morelines;
    output.open("countwords_output.txt");
    while (getline(teststream, morelines))
    {
        // Parse variable line from strings to char*
        char *word = strtok((char *)morelines.c_str(), DELIMITERS);
        while (word != nullptr)
        {
            // lowercase the word
            for (int i = 0; i < strlen(word); i++)
            {
                word[i] = tolower(word[i]);
            }

            // call search method to count how many words starts with given prefix
            int count = search(exe->root, word);
            // print the result
            if (exe->minNumOfWordsWithAPrefixForPrinting <= count)
            {
                output << word << " " << count << endl;
            }
            // Add char count to exe->numOfCharsProcessedFromTestFile
            exe->numOfCharsProcessedFromTestFile += strlen(word) + 2; // Delimiter is included;
            // And declaring an variable or macro for this is unreasonable.

            exe->wordCountInTestFile++;

            // read next word
            word = strtok(NULL, DELIMITERS);
        }
    }
    teststream.close();
    output.close();
    exe->taskCompletedForTestFile = true;
    return NULL;
}