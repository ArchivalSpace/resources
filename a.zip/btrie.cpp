#define NUMOFCHARS 27 /* a-z plus ' */
#define APOSTROPHE 26
#include <string>
#include <cstring>
#include <iostream>

#include "btrie.h"

struct dictNode *getNode()
{
    /* Adds a certain word to the trie */
    struct dictNode *pNode = new dictNode;
    pNode->isWord = false;
    for (int i = 0; i < NUMOFCHARS; i++)
    {
        pNode->next[i] = NULL;
    }
    return pNode;
}

bool addToDictionary(struct dictNode *root, std::string word)
{
    /* Adds a certain word to the trie */
    try
    {
        struct dictNode *node = root;
        for (int i = 0; i < word.length(); i++)
        {
            int index = word[i] - 'a';
            if (word[i] == '\'')
            {
                index = APOSTROPHE;
            }
            if (!node->next[index])
            {
                node->next[index] = getNode();
            }
            node = node->next[index];
        }
        node->isWord = true;
        return true;
    }
    catch (const std::exception &e)
    {
        std::cerr << e.what() << '\n';
        return false;
    }
}
