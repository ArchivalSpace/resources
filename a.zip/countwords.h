#ifndef COUNTWORDS_H
#define COUNTWORDS_H

#include <string>

int depthSearch(struct dictNode *currentnode, int &count);
int search(struct dictNode *root, std::string prefix);

#endif