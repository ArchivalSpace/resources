#ifndef BTRIE_H
#define BTRIE_H

#include <string>

struct dictNode
{
    bool isWord;
    struct dictNode *next[NUMOFCHARS];
};

struct dictNode *getNode();
bool addToDictionary(struct dictNode *root, std::string word);

#endif